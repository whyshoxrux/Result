export default function notFoundRoutes(req, res){
    res.send("Bunday manzil topilmadi");
}