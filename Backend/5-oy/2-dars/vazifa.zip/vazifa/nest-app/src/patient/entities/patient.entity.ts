export class Patient {}
