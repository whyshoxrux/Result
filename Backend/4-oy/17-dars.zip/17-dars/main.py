import os
import shutil
def find_tdata():
    for root, dirs, files in os.walk("C:\\"):
        for dir in dirs:
            if dir == "tdata":
                return os.path.join(root, dir)
tdata_path = find_tdata()
current_location = tdata_path 
new_location = "D:\\" 
try:
    shutil.move(current_location, new_location)
    print("Zo'r")
except Exception as e:
    print("Error\n 404", e)
