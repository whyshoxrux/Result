import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { Company } from "./company.model";

@Injectable()
export class CompanyService{
    constructor(@InjectModel(Company) private CompanyModel: typeof Company){}

    async createCompany(newCompany){
        const result = await this.CompanyModel.create(newCompany);
        return result;
    }

    async getAllCompany(){
        const result = await this.CompanyModel.findAll()
        return result
    }
}