import { IsNotEmpty, IsString } from "class-validator";

export class createCompanyDto{
    @IsString()
    @IsNotEmpty()
    name: string;

    @IsString()
    @IsNotEmpty()
    address: string
}