import { Model, Column, DataType, HasMany, Table } from 'sequelize-typescript';
import { Employee } from 'src/employee/employee.model'; // To'g'ri yo'lni tekshirish

@Table({ tableName: 'company' })
export class Company extends Model<Company> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  address: string;

  @HasMany(() => Employee)
  employees: Employee[];
}
