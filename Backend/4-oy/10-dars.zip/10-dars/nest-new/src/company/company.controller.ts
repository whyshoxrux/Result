import { Body, Controller, Get, Post } from '@nestjs/common';
import { CompanyService } from './company.service';
import { createCompanyDto } from './dto/company.dto';

@Controller('company')
export class CompanyController {
  constructor(private companyService: CompanyService) {}

  @Post()
  async createCompany(@Body() createCompanyDto: createCompanyDto) {
      
      const result = await this.companyService.createCompany(createCompanyDto);
      console.log(1)
    return result;
  }

  @Get()
  getAllCompany() {
    return this.companyService.getAllCompany();
  }
}
