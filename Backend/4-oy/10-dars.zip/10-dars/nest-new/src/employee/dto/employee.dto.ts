import { IsNotEmpty, IsNumber, IsString } from "class-validator";

export class CreateEmployeeDto{
    @IsString()
    @IsNotEmpty()
    name: string;

    @IsString()
    @IsNotEmpty()
    address: string;

    @IsNumber()
    @IsNotEmpty()
    company_id: number
}