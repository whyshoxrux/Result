import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { Employee } from "./employee.model";
import { Company } from "src/company/company.model";
import { EmployeeController } from "./employee.controller";
import { CompanyService } from "src/company/company.service";
import { EmployeeService } from "./employee.service";

@Module({
    imports: [SequelizeModule.forFeature([Employee, Company])],
    controllers: [EmployeeController],
    providers: [EmployeeService]
})
export class EmployeeModule{}