import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { Employee } from "./employee.model";
import { Company } from "src/company/company.model";

@Injectable()
export class EmployeeService{
    constructor (@InjectModel(Employee) private employeeModel: typeof Employee){}

    async createEmployee(newEmployee){
        const result = await this.employeeModel.create(newEmployee);
        return result;
    }

    async getAllEmployee(){
        const result = await this.employeeModel.findAll({
            include: [{model: Company}]
        })
        return result
    }
}