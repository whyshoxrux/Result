import { Body, Controller, Get, Post } from "@nestjs/common";
import { EmployeeService } from "./employee.service";
import { CreateEmployeeDto } from "./dto/employee.dto";

@Controller('employee')
export class EmployeeController{
    constructor(private employeeService: EmployeeService){}

    @Post()
    async createEmployee(@Body() createEmployeeDto: CreateEmployeeDto){
        const result = await this.employeeService.createEmployee(createEmployeeDto);
        return result;
    }

    @Get()
    getAllEmployee(){
        return this.employeeService.getAllEmployee()
    }
}