import {
  Model,
  Column,
  DataType,
  ForeignKey,
  BelongsTo,
  Table,
} from 'sequelize-typescript';
import {Company} from '../company/company.model'


@Table({ tableName: 'employees' })
export class Employee extends Model<Employee> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  address: string;

  @ForeignKey(() => Company) // Foreign keyni ko'rsatish
  @Column({
    type: DataType.INTEGER, // NUMBER o'rniga INTEGER bo'lishi kerak
    allowNull: false,
  })
  company_id: number;

  @BelongsTo(() => Company) // Employee modeli Company bilan bog'lanadi
  company: Company[];
}
