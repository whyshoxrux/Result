import { Module } from '@nestjs/common';
import { CourseStudentsService } from './course-students.service';
import { CourseStudentsController } from './course-students.controller';
import { SequelizeModule } from '@nestjs/sequelize';
import { Mod } from './model';
import { Course } from 'src/courses/course.model';
import { Student } from 'src/students/student.model';

@Module({
  imports: [SequelizeModule.forFeature([Mod, Course, Student])],
  controllers: [CourseStudentsController],
  providers: [CourseStudentsService],
})
export class CourseStudentsModule {}
