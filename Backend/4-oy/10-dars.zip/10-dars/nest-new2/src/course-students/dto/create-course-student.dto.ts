import { IsNotEmpty, IsNumber, IsString } from "class-validator";

export class CreateCourseStudentDto {
    @IsNumber()
    @IsNotEmpty()
    course_id: number;

    @IsNumber()
    @IsNotEmpty()
    student_id: number
}
