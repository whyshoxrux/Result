import {
  Column,
  Model,
  DataType,
  ForeignKey,
  Table,
} from 'sequelize-typescript';
import { Course } from 'src/courses/course.model';
import { Student } from 'src/students/student.model';

@Table({ tableName: 'courseStudents' })
export class Mod extends Model<Mod> {
  @ForeignKey(() => Student)
  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  student_id: number;
  @ForeignKey(() => Course)
  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  course_id: number;
}
