import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { CourseStudentsService } from './course-students.service';
import { CreateCourseStudentDto } from './dto/create-course-student.dto';

@Controller('course-students')
export class CourseStudentsController {
  constructor(private readonly courseStudentsService: CourseStudentsService) {}

  @Post()
  create(@Body() createCourseStudentDto: CreateCourseStudentDto) {
    return this.courseStudentsService.createCS(createCourseStudentDto);
  }

  @Get()
  findAll() {
    return this.courseStudentsService.findAll();
  }
}
