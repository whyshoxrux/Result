import { Injectable } from '@nestjs/common';
import { CreateCourseStudentDto } from './dto/create-course-student.dto';
import { UpdateCourseStudentDto } from './dto/update-course-student.dto';
import { InjectModel } from '@nestjs/sequelize';
import { Mod } from './model';

@Injectable()
export class CourseStudentsService {
  constructor(@InjectModel(Mod) private CourseStudentModel: typeof Mod) {
  }

  async createCS(newCS) {
    const result = await this.CourseStudentModel.create(newCS)
    return result;
  }

  async findAll() {
    const result = await this.CourseStudentModel.findAll()
    return result
  }

  update(id: number, updateCourseStudentDto: UpdateCourseStudentDto) {
    return `This action updates a #${id} courseStudent`;
  }

  remove(id: number) {
    return `This action removes a #${id} courseStudent`;
  }
}
