import { Body, Controller, Get, Post } from "@nestjs/common";
import { StudentService } from "./student.service";
import { CreateStudentDto } from "./dto/students.dto";

@Controller('student')
export class StudetnController{
    constructor(private studentService: StudentService){}

    @Post()
    async createStudent(@Body() createStudentDto: CreateStudentDto){
        const result = await this.studentService.createStudent(createStudentDto);
        return result;
    }

    @Get()
    getAllStudent(){
        return this.studentService.getAllStudent();
    }
}