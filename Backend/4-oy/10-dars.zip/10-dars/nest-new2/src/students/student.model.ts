import {
  Model,
  BelongsToMany,
  Column,
  DataType,
  ForeignKey,
  HasMany,
  Table,
} from 'sequelize-typescript';
import { Mod } from 'src/course-students/model';
import { Course } from 'src/courses/course.model';

@Table({ tableName: 'students' })
export class Student extends Model<Student> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  name: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  address: string;

  //   @ForeignKey(() => Course)

  //   @Column({
  //     type: DataType.INTEGER,
  //     allowNull: false,
  //   })
  //   course_id: number;

  @BelongsToMany(() => Course, () => Mod)
  courses: Course[];
}
