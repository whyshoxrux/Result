import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { Student } from "./student.model";

@Injectable()
export class StudentService{
    constructor(@InjectModel(Student) private StudentModel: typeof Student){}

    async createStudent(newStudent){
        const result = await this.StudentModel.create(newStudent);
        return result
    }

    async getAllStudent(){
        const result = await this.StudentModel.findAll({
        
        })
        return result;
    }
}