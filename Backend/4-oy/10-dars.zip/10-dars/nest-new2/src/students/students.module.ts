import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import { Student } from "./student.model";
import { StudetnController } from "./student.controller";
import { StudentService } from "./student.service";

@Module({
    imports: [SequelizeModule.forFeature([Student])],
    controllers: [StudetnController],
    providers: [StudentService],
})
export class StudentModule{}