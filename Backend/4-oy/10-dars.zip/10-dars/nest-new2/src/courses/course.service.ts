import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { Course } from "./course.model";

@Injectable()
export class CourseService{
    constructor (@InjectModel(Course) private courseModel: typeof Course){}

    async createCourse(newCourse){
        const result = await this.courseModel.create(newCourse);
        return result;
    }

    async getAllCourses(){
        const result = await this.courseModel.findAll({})
        return result
    }
}