import {
  Model,
  BelongsToMany,
  Column,
  DataType,
  Table,
} from 'sequelize-typescript';
import { Mod } from 'src/course-students/model';
import { Student } from 'src/students/student.model';

@Table({ tableName: 'courses' })
export class Course extends Model<Course> {
  @Column({
    type: DataType.STRING,
    allowNull: false,
  })
  course_name: string;

  @BelongsToMany(() => Student, () => Mod)
  students;
}
