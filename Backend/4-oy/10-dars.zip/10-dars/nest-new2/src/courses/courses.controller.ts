import { Body, Controller, Get, Post } from "@nestjs/common";
import { CourseService } from "./course.service";
import { CreateCourseDto } from "./dto/course.dto";

@Controller('course')
export class CourseController{
    constructor(private courseService: CourseService){}

    @Post()
    async createCourse(@Body() createCourseDto: CreateCourseDto){
        const result = await this.courseService.createCourse(createCourseDto)
        return result
    }

    @Get()
    getAllCourses(){
        return this.courseService.getAllCourses()
    }
}