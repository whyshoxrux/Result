import { Module } from '@nestjs/common';
import { CourseModule } from './courses/course.module';
import { StudentModule } from './students/students.module';
import { SequelizeModule } from '@nestjs/sequelize';
import { CourseStudentsModule } from './course-students/course-students.module';

@Module({
  imports: [
    CourseModule,
    StudentModule,
    SequelizeModule.forRoot({
      dialect: 'postgres',
      database: 'postgres',
      username: 'postgres',
      password: '123456',
      host: '127.0.0.1',
      port: 5432,
      autoLoadModels: true,
      synchronize: true
    }),
    CourseStudentsModule
  ]
})
export class AppModule {}
