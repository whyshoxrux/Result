import {
    elTodoTemplate,
    elTodosParent,
    elTodoForm
} from "./html-selection.js";

elTodoForm.onSubmit = function (e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const todoName = data.get("todoName");
    const todoBody = data.get("todoBody");
    const element = elTodoTemplate.contentEditable.cloneNode(true);
    elTodosParent.appendChild(element)

    console.log(elTodoForm)
}