const elTodosParent = document.getElementById("todosParent")
const elTodoTemplate = document.getElementById("todoTemplate")
const elTodoForm = document.getElementById("todoForm")

export {
    elTodosParent,
    elTodoTemplate,
    elTodoForm
}